# AroggoLipi
this is a Centralized patient management and prescription writing web application designed using python Django, Ajax, and SQL <br>

Here are some screenshots of the application <br>
<br>
![image](https://user-images.githubusercontent.com/45464612/194613414-02b99e9b-640e-442e-9486-fe0d1634a88c.png)
<br>

<br>![image](https://user-images.githubusercontent.com/45464612/194613543-05282b5b-ebd3-4fee-b402-1f43acadf20b.png)
<br>
<br>![image](https://user-images.githubusercontent.com/45464612/194614136-f7eba5b3-ab58-4aca-8703-8165d90abe31.png)
<br>
<br>![image](https://user-images.githubusercontent.com/45464612/194614214-fb30e451-6404-4741-8999-17a2ca110956.png)
<br>

hospital approval dashboard for doctors
![image](https://user-images.githubusercontent.com/45464612/202781859-0b7abdeb-d0b9-44d2-9c8a-3614661b7265.png)

doctors prescription panel
![image](https://user-images.githubusercontent.com/45464612/202781968-502afc34-bd01-44eb-aa82-b29f88727931.png)

patient report panel
![image](https://user-images.githubusercontent.com/45464612/202781944-a81421d8-1c6e-4cb9-a4e9-9da90c105d2c.png)

