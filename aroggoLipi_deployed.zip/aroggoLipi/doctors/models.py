

# Create your models here.

# docLogin model
# docRegister model

from django.db import models
from django.db.models.base import Model

#


# class doctorsInfo(models.Model):
#     docName = models.CharField(max_length=100)
#     docNID = models.IntegerField()
#     docDOB = models.DateField()
#     docHospital = models.CharField(max_length=100)
#     docDepartment = models.CharField(max_length=100)
#     docEID = models.CharField(max_length=100)
#     docPhone = models.CharField(max_length=20)
#     docEmail = models.CharField(max_length=50)
#     docPassword = models.TextField()
#     docImage = models.ImageField(upload_to='doctorsUploadedImage')